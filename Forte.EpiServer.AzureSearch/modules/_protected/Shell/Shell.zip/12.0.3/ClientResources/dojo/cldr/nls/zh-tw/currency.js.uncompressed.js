define(
"dojo/cldr/nls/zh-tw/currency", //begin v1.x content
{
	"HKD_displayName": "港幣",
	"JPY_symbol": "¥",
	"CAD_displayName": "加幣",
	"CNY_displayName": "人民幣",
	"USD_symbol": "$",
	"AUD_displayName": "澳幣",
	"JPY_displayName": "日圓",
	"USD_displayName": "美金",
	"GBP_displayName": "英鎊",
	"EUR_displayName": "歐元"
}
//end v1.x content
);